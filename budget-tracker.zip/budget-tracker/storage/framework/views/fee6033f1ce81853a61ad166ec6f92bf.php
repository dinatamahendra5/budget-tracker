

<?php $__env->startSection('title', 'Anggaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Anggaran</h4>
    <a href="<?php echo e(route('budgets.create', ['month' => $month, 'year' => $year])); ?>"
       class="btn btn-primary">+ Tambah Anggaran</a>
</div>


<form method="GET" action="<?php echo e(route('budgets.index')); ?>" class="row g-2 mb-3">
    <div class="col-auto">
        <select name="month" class="form-select">
            <?php $__currentLoopData = \App\Models\Budget::MONTHS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($num); ?>" <?php if($month === $num): echo 'selected'; endif; ?>><?php echo e($nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-auto">
        <input type="number" name="year" value="<?php echo e($year); ?>" min="2020" max="2100" class="form-control">
    </div>
    <div class="col-auto">
        <button class="btn btn-outline-primary">Tampilkan</button>
    </div>
</form>


<?php $__currentLoopData = $budgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($b->status === 'danger'): ?>
        <div class="alert alert-danger py-2">
            <strong><?php echo e($b->category->name); ?></strong> sudah mencapai atau melewati batas anggaran (<?php echo e($b->persen); ?>%).
        </div>
    <?php elseif($b->status === 'warning'): ?>
        <div class="alert alert-warning py-2">
            <strong><?php echo e($b->category->name); ?></strong> sudah terpakai <?php echo e($b->persen); ?>%, hampir mencapai batas anggaran.
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Kategori</th>
                    <th style="min-width: 240px;">Terpakai</th>
                    <th class="text-end">Anggaran</th>
                    <th class="text-end">Sisa</th>
                    <th class="text-end">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $budgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php $sisa = $b->amount - $b->terpakai; ?>
                    <tr>
                        <td><?php echo e($b->category->name); ?></td>
                        <td>
                            <div class="progress" style="height: 22px;">
                                <div class="progress-bar bg-<?php echo e($b->status); ?> <?php echo e($b->status === 'warning' ? 'text-dark' : ''); ?>"
                                     style="width: <?php echo e(min($b->persen, 100)); ?>%;">
                                    <?php echo e($b->persen); ?>%
                                </div>
                            </div>
                            <div class="small text-muted mt-1">
                                Rp <?php echo e(number_format($b->terpakai, 0, ',', '.')); ?>

                            </div>
                        </td>
                        <td class="text-end">Rp <?php echo e(number_format($b->amount, 0, ',', '.')); ?></td>
                        <td class="text-end <?php echo e($sisa < 0 ? 'text-danger fw-semibold' : ''); ?>">
                            <?php if($sisa < 0): ?>
                                Melebihi Rp <?php echo e(number_format(abs($sisa), 0, ',', '.')); ?>

                            <?php else: ?>
                                Rp <?php echo e(number_format($sisa, 0, ',', '.')); ?>

                            <?php endif; ?>
                        </td>
                        <td class="text-end">
                            <div class="d-inline-flex gap-2">
                                <a href="<?php echo e(route('budgets.edit', $b)); ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                <form method="POST" action="<?php echo e(route('budgets.destroy', $b)); ?>"
                                      onsubmit="return confirm('Hapus anggaran ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">
                            Belum ada anggaran untuk <?php echo e(\App\Models\Budget::MONTHS[$month]); ?> <?php echo e($year); ?>.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\budget-tracker\resources\views/budgets/index.blade.php ENDPATH**/ ?>