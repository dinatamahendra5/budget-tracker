

<?php $__env->startSection('title', 'Tabungan'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Target Tabungan</h4>
    <a href="<?php echo e(route('savings-goals.create')); ?>" class="btn btn-primary">+ Tambah Target</a>
</div>

<div class="row g-3">
    <?php $__empty_1 = true; $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-6">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <h5 class="mb-1"><?php echo e($g->name); ?></h5>
                        <?php if($g->tercapai): ?>
                            <span class="badge text-bg-success">Tercapai</span>
                        <?php elseif($g->terlambat): ?>
                            <span class="badge text-bg-danger">Lewat tenggat</span>
                        <?php endif; ?>
                    </div>

                    <div class="text-muted small mb-2">
                        <?php if($g->deadline): ?>
                            Tenggat: <?php echo e($g->deadline->format('d M Y')); ?>

                        <?php else: ?>
                            Tanpa tenggat
                        <?php endif; ?>
                    </div>

                    <div class="progress mb-2" style="height: 22px;">
                        <div class="progress-bar <?php echo e($g->tercapai ? 'bg-success' : 'bg-primary'); ?>"
                             style="width: <?php echo e($g->persen); ?>%;"><?php echo e($g->persen); ?>%</div>
                    </div>

                    <div class="d-flex justify-content-between small">
                        <span>Rp <?php echo e(number_format($g->terkumpul, 0, ',', '.')); ?></span>
                        <span class="text-muted">dari Rp <?php echo e(number_format($g->target_amount, 0, ',', '.')); ?></span>
                    </div>

                    <div class="small text-muted mt-2">Estimasi tercapai: <?php echo e($g->estimasi); ?></div>
                </div>
                <div class="card-footer bg-transparent">
                    <a href="<?php echo e(route('savings-goals.show', $g)); ?>" class="btn btn-sm btn-outline-primary">Detail &amp; Setoran</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-body text-center text-muted py-4">
                    Belum ada target tabungan. Klik "+ Tambah Target" untuk membuat yang pertama.
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\budget-tracker\resources\views/savings/index.blade.php ENDPATH**/ ?>