<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Keuangan Pribadi'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">Keuangan Pribadi</a>

        <?php if(auth()->guard()->check()): ?>
            <ul class="navbar-nav flex-row gap-3 me-auto ms-4">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>"
                    href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('categories.*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('categories.index')); ?>">Kategori</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('transactions.*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('transactions.index')); ?>">Transaksi</a>
                </li>
                    <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('budgets.*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('budgets.index')); ?>">Anggaran</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('savings-goals.*', 'savings-deposits.*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('savings-goals.index')); ?>">Tabungan</a>
                </li>
            </ul>

            <div class="d-flex align-items-center gap-3">
                <span class="text-white"><?php echo e(auth()->user()->name); ?></span>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-sm btn-light">Logout</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</nav>

<main class="container py-4">
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

        <?php if(session('budget_alert')): ?>
        <?php $alert = session('budget_alert'); ?>
        <div class="alert alert-<?php echo e($alert['level']); ?>"><?php echo e($alert['message']); ?></div>
        <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</main>

</body>
</html><?php /**PATH C:\Users\Lenovo\budget-tracker\resources\views/layouts/app.blade.php ENDPATH**/ ?>