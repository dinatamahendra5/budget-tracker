

<?php $__env->startSection('title', 'Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Transaksi</h4>
    <a href="<?php echo e(route('transactions.create')); ?>" class="btn btn-primary">+ Tambah Transaksi</a>
</div>


<form method="GET" action="<?php echo e(route('transactions.index')); ?>" class="card shadow-sm mb-3">
    <div class="card-body">
        <div class="row g-2">
            <div class="col-md-4">
                <label class="form-label small mb-1">Cari</label>
                <input type="text" name="q" value="<?php echo e(request('q')); ?>"
                class="form-control" placeholder="Keterangan atau kategori">
            </div>

            <div class="col-md-2">
                <label class="form-label small mb-1">Tipe</label>
                <select name="type" class="form-select">
                    <option value="">Semua</option>
                    <option value="income" <?php if(request('type') === 'income'): echo 'selected'; endif; ?>>Pemasukan</option>
                    <option value="expense" <?php if(request('type') === 'expense'): echo 'selected'; endif; ?>>Pengeluaran</option>
                </select>
            </div>

            <div class="col-md-3">
                <label class="form-label small mb-1">Kategori</label>
                <select name="category_id" class="form-select">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($c->id); ?>" <?php if((string) request('category_id') === (string) $c->id): echo 'selected'; endif; ?>>
                            <?php echo e($c->name); ?> (<?php echo e($c->type === 'income' ? 'Masuk' : 'Keluar'); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-3"></div>

            <div class="col-md-3">
                <label class="form-label small mb-1">Dari tanggal</label>
                <input type="date" name="from" value="<?php echo e(request('from')); ?>"
                       class="form-control <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3">
                <label class="form-label small mb-1">Sampai tanggal</label>
                <input type="date" name="to" value="<?php echo e(request('to')); ?>"
                       class="form-control <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 d-flex align-items-end gap-2">
                <button class="btn btn-primary">Terapkan</button>
                <a href="<?php echo e(route('transactions.index')); ?>" class="btn btn-outline-secondary">Reset</a>
            </div>
        </div>
    </div>
</form>


<div class="row g-3 mb-3">
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body py-2">
                <div class="text-muted small">Jumlah transaksi</div>
                <div class="fw-bold"><?php echo e($transactions->total()); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body py-2">
                <div class="text-muted small">Total pemasukan</div>
                <div class="fw-bold text-success">Rp <?php echo e(number_format($totalPemasukan, 0, ',', '.')); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body py-2">
                <div class="text-muted small">Total pengeluaran</div>
                <div class="fw-bold text-danger">Rp <?php echo e(number_format($totalPengeluaran, 0, ',', '.')); ?></div>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Tanggal</th>
                    <th>Kategori</th>
                    <th>Keterangan</th>
                    <th class="text-end">Jumlah</th>
                    <th class="text-end">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($t->transaction_date->format('d M Y')); ?></td>
                        <td><?php echo e($t->category->name); ?></td>
                        <td class="text-muted"><?php echo e($t->description); ?></td>
                        <td class="text-end fw-semibold <?php echo e($t->isIncome() ? 'text-success' : 'text-danger'); ?>">
                            <?php echo e($t->isIncome() ? '+' : '-'); ?> Rp <?php echo e(number_format($t->amount, 0, ',', '.')); ?>

                        </td>
                        <td class="text-end">
                            <div class="d-inline-flex gap-2">
                                <a href="<?php echo e(route('transactions.edit', $t)); ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                <form method="POST" action="<?php echo e(route('transactions.destroy', $t)); ?>"
                                      onsubmit="return confirm('Hapus transaksi ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">
                            Tidak ada transaksi yang cocok.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">
    <?php echo e($transactions->links('pagination::bootstrap-5')); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\budget-tracker\resources\views/transactions/index.blade.php ENDPATH**/ ?>