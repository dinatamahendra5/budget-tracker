

<?php $__env->startSection('title', 'Kategori'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Kategori</h4>
    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">+ Tambah Kategori</a>
</div>

<div class="row g-3">
    <?php $__currentLoopData = ['expense' => $expense, 'income' => $income]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header fw-semibold"><?php echo e(\App\Models\Category::TYPES[$type]); ?></div>
                <ul class="list-group list-group-flush">
                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <?php echo e($c->name); ?>

                            <span class="badge text-bg-secondary"><?php echo e($c->transactions_count); ?></span>
                            <span class="d-flex gap-2">
                                <a href="<?php echo e(route('categories.edit', $c)); ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                <form method="POST" action="<?php echo e(route('categories.destroy', $c)); ?>"
                                    onsubmit="return confirm('Hapus kategori ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                            </span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item text-muted">Belum ada kategori.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\budget-tracker\resources\views/categories/index.blade.php ENDPATH**/ ?>