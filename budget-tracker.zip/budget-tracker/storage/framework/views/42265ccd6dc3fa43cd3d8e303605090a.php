<?php echo csrf_field(); ?>

<?php
    $selectedType = old('type', $transaction->type ?? 'expense');
    $selectedCategory = old('category_id', $transaction->category_id ?? '');
?>

<div class="mb-3">
    <label class="form-label d-block">Tipe</label>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="type" id="type_expense" value="expense"
               <?php if($selectedType === 'expense'): echo 'checked'; endif; ?>>
        <label class="form-check-label" for="type_expense">Pengeluaran</label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="type" id="type_income" value="income"
               <?php if($selectedType === 'income'): echo 'checked'; endif; ?>>
        <label class="form-check-label" for="type_income">Pemasukan</label>
    </div>
    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="mb-3">
    <label class="form-label">Kategori</label>
    <select name="category_id" id="category_id"
            class="form-select <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></select>
    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="mb-3">
    <label class="form-label">Nominal (Rp)</label>
    <input type="number" name="amount" min="1" step="1"
           value="<?php echo e(old('amount', $transaction->amount ?? '')); ?>"
           class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="mb-3">
    <label class="form-label">Tanggal</label>
    <input type="date" name="transaction_date" max="<?php echo e(now()->format('Y-m-d')); ?>"
           value="<?php echo e(old('transaction_date', isset($transaction) ? $transaction->transaction_date->format('Y-m-d') : now()->format('Y-m-d'))); ?>"
           class="form-control <?php $__errorArgs = ['transaction_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    <?php $__errorArgs = ['transaction_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="mb-3">
    <label class="form-label">Keterangan (opsional)</label>
    <input type="text" name="description" maxlength="255"
        value="<?php echo e(old('description', $transaction->description ?? '')); ?>"
        class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<button class="btn btn-primary">Simpan</button>
<a href="<?php echo e(route('transactions.index')); ?>" class="btn btn-secondary">Batal</a>

<script>
    const categories = <?php echo json_encode($categories, 15, 512) ?>;
    const selectedCategory = "<?php echo e($selectedCategory); ?>";
    const select = document.getElementById('category_id');

    function renderOptions(keepSelected) {
        const type = document.querySelector('input[name="type"]:checked').value;

        select.innerHTML = '<option value="">-- Pilih kategori --</option>';

        categories.filter(c => c.type === type).forEach(c => {
            const option = document.createElement('option');
            option.value = c.id;
            option.textContent = c.name;
            if (keepSelected && String(c.id) === selectedCategory) {
                option.selected = true;
            }
            select.appendChild(option);
        });
    }

    document.querySelectorAll('input[name="type"]').forEach(radio => {
        radio.addEventListener('change', () => renderOptions(false));
    });

    renderOptions(true);
</script><?php /**PATH C:\Users\Lenovo\budget-tracker\resources\views/transactions/_form.blade.php ENDPATH**/ ?>