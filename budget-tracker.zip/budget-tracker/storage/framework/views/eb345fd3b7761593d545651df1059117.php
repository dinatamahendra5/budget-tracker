

<?php $__env->startSection('title', 'Edit Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body">
                <h4 class="mb-3">Edit Transaksi</h4>
                <form method="POST" action="<?php echo e(route('transactions.update', $transaction)); ?>">
                    <?php echo method_field('PUT'); ?>
                    <?php echo $__env->make('transactions._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\budget-tracker\resources\views/transactions/edit.blade.php ENDPATH**/ ?>