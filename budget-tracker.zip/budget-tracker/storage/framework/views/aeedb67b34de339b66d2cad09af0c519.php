

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<h4 class="mb-3">Dashboard</h4>

<?php $__currentLoopData = $peringatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-<?php echo e($b->status); ?> py-2">
        <strong><?php echo e($b->category->name); ?></strong>
        sudah terpakai <?php echo e($b->persen); ?>% dari anggaran bulan ini
        (Rp <?php echo e(number_format($b->terpakai, 0, ',', '.')); ?> dari Rp <?php echo e(number_format($b->amount, 0, ',', '.')); ?>).
        <a href="<?php echo e(route('budgets.index')); ?>" class="alert-link">Lihat anggaran</a>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <div class="text-muted small">Sisa uang</div>
                <div class="fs-4 fw-bold <?php echo e($sisaUang < 0 ? 'text-danger' : ''); ?>">
                    Rp <?php echo e(number_format($sisaUang, 0, ',', '.')); ?>

                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <div class="text-muted small">Pemasukan bulan ini (<?php echo e(now()->format('m/Y')); ?>)</div>
                <div class="fs-4 fw-bold text-success">
                    Rp <?php echo e(number_format($pemasukanBulanIni, 0, ',', '.')); ?>

                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <div class="text-muted small">Pengeluaran bulan ini (<?php echo e(now()->format('m/Y')); ?>)</div>
                <div class="fs-4 fw-bold text-danger">
                    Rp <?php echo e(number_format($pengeluaranBulanIni, 0, ',', '.')); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span class="fw-semibold">5 transaksi terakhir</span>
        <a href="<?php echo e(route('transactions.create')); ?>" class="btn btn-sm btn-primary">+ Tambah Transaksi</a>
    </div>
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $transaksiTerakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($t->transaction_date->format('d M Y')); ?></td>
                        <td><?php echo e($t->category->name); ?></td>
                        <td class="text-muted"><?php echo e($t->description); ?></td>
                        <td class="text-end fw-semibold <?php echo e($t->isIncome() ? 'text-success' : 'text-danger'); ?>">
                            <?php echo e($t->isIncome() ? '+' : '-'); ?> Rp <?php echo e(number_format($t->amount, 0, ',', '.')); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="text-center text-muted py-4">Belum ada transaksi.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\budget-tracker\resources\views/dashboard.blade.php ENDPATH**/ ?>