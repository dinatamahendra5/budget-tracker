

<?php $__env->startSection('title', $goal->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><?php echo e($goal->name); ?></h4>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('savings-goals.index')); ?>" class="btn btn-outline-secondary btn-sm">&laquo; Kembali</a>
        <a href="<?php echo e(route('savings-goals.edit', $goal)); ?>" class="btn btn-outline-primary btn-sm">Edit</a>
        <form method="POST" action="<?php echo e(route('savings-goals.destroy', $goal)); ?>"
              onsubmit="return confirm('Hapus target ini? Semua setorannya ikut terhapus dan uangnya kembali ke sisa uang.')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-outline-danger btn-sm">Hapus</button>
        </form>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-8">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <div class="progress mb-2" style="height: 28px;">
                    <div class="progress-bar <?php echo e($goal->tercapai ? 'bg-success' : 'bg-primary'); ?>"
                         style="width: <?php echo e($goal->persen); ?>%;"><?php echo e($goal->persen); ?>%</div>
                </div>

                <div class="row text-center mt-3">
                    <div class="col">
                        <div class="text-muted small">Terkumpul</div>
                        <div class="fw-bold text-success">Rp <?php echo e(number_format($goal->terkumpul, 0, ',', '.')); ?></div>
                    </div>
                    <div class="col">
                        <div class="text-muted small">Target</div>
                        <div class="fw-bold">Rp <?php echo e(number_format($goal->target_amount, 0, ',', '.')); ?></div>
                    </div>
                    <div class="col">
                        <div class="text-muted small">Kurang</div>
                        <div class="fw-bold">Rp <?php echo e(number_format($goal->sisa, 0, ',', '.')); ?></div>
                    </div>
                </div>

                <hr>

                <div class="small">
                    <div class="mb-1">
                        <span class="text-muted">Estimasi tercapai:</span>
                        <strong><?php echo e($goal->estimasi); ?></strong>
                    </div>

                    <?php if($goal->rata_setoran): ?>
                        <div class="mb-1">
                            <span class="text-muted">Rata-rata setoran per bulan:</span>
                            <strong>Rp <?php echo e(number_format($goal->rata_setoran, 0, ',', '.')); ?></strong>
                        </div>
                    <?php endif; ?>

                    <?php if($goal->deadline): ?>
                        <div class="mb-1">
                            <span class="text-muted">Tenggat:</span>
                            <strong><?php echo e($goal->deadline->format('d M Y')); ?></strong>
                        </div>
                    <?php endif; ?>

                    <?php if($goal->terlambat): ?>
                        <div class="text-danger fw-semibold">Tenggat sudah lewat dan target belum tercapai.</div>
                    <?php elseif($goal->kebutuhan_bulanan): ?>
                        <div>
                            <span class="text-muted">Perlu menyetor:</span>
                            <strong>Rp <?php echo e(number_format($goal->kebutuhan_bulanan, 0, ',', '.')); ?> / bulan</strong>
                            <span class="text-muted">agar tercapai sebelum tenggat</span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <h6 class="mb-1">Tambah setoran</h6>
                <div class="text-muted small mb-3">
                    Sisa uang tersedia: Rp <?php echo e(number_format(max($saldo, 0), 0, ',', '.')); ?>

                </div>

                <form method="POST" action="<?php echo e(route('savings-deposits.store', $goal)); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="mb-2">
                        <label class="form-label small mb-1">Nominal (Rp)</label>
                        <input type="number" name="amount" min="1" step="1" value="<?php echo e(old('amount')); ?>"
                               class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-2">
                        <label class="form-label small mb-1">Tanggal</label>
                        <input type="date" name="deposit_date" max="<?php echo e(now()->format('Y-m-d')); ?>"
                               value="<?php echo e(old('deposit_date', now()->format('Y-m-d'))); ?>"
                               class="form-control <?php $__errorArgs = ['deposit_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['deposit_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small mb-1">Catatan (opsional)</label>
                        <input type="text" name="note" maxlength="255" value="<?php echo e(old('note')); ?>"
                               class="form-control <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button class="btn btn-primary w-100">Setor</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header fw-semibold">Riwayat setoran</div>
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($d->deposit_date->format('d M Y')); ?></td>
                        <td class="text-muted"><?php echo e($d->note); ?></td>
                        <td class="text-end fw-semibold text-success">
                            + Rp <?php echo e(number_format($d->amount, 0, ',', '.')); ?>

                        </td>
                        <td class="text-end">
                            <div class="d-inline-flex gap-2">
                                <a href="<?php echo e(route('savings-deposits.edit', $d)); ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                <form method="POST" action="<?php echo e(route('savings-deposits.destroy', $d)); ?>"
                                      onsubmit="return confirm('Hapus setoran ini? Uangnya kembali ke sisa uang.')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="text-center text-muted py-4">Belum ada setoran.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\budget-tracker\resources\views/savings/show.blade.php ENDPATH**/ ?>