<?php

namespace App\Http\Controllers;

use App\Http\Requests\SavingsDepositRequest;
use App\Models\SavingsDeposit;
use App\Models\SavingsGoal;

class SavingsDepositController extends Controller
{
    public function store(SavingsDepositRequest $request, SavingsGoal $savingsGoal)
    {
        abort_if($savingsGoal->user_id !== auth()->id(), 403);

        // user_id dan savings_goal_id diisi lewat relasi, bukan dari input form
        $deposit = $savingsGoal->deposits()->make($request->validated());
        $deposit->user()->associate($request->user());
        $deposit->save();

        $terkumpul = (int) $savingsGoal->deposits()->sum('amount');

        $pesan = $terkumpul >= $savingsGoal->target_amount
            ? "Selamat! Target \"{$savingsGoal->name}\" sudah tercapai."
            : 'Setoran berhasil ditambahkan.';

        return redirect()->route('savings-goals.show', $savingsGoal)->with('success', $pesan);
    }

    public function edit(SavingsDeposit $savingsDeposit)
    {
        $this->pastikanMilikSendiri($savingsDeposit);

        return view('savings.deposit-edit', [
            'deposit' => $savingsDeposit,
            'goal' => $savingsDeposit->goal,
        ]);
    }

    public function update(SavingsDepositRequest $request, SavingsDeposit $savingsDeposit)
    {
        $this->pastikanMilikSendiri($savingsDeposit);

        $savingsDeposit->update($request->validated());

        return redirect()->route('savings-goals.show', $savingsDeposit->savings_goal_id)
            ->with('success', 'Setoran berhasil diperbarui.');
    }

    public function destroy(SavingsDeposit $savingsDeposit)
    {
        $this->pastikanMilikSendiri($savingsDeposit);

        $goalId = $savingsDeposit->savings_goal_id;

        $savingsDeposit->delete(); // saldo otomatis kembali, karena dihitung dari tabel setoran

        return redirect()->route('savings-goals.show', $goalId)
            ->with('success', 'Setoran berhasil dihapus.');
    }

    private function pastikanMilikSendiri(SavingsDeposit $deposit): void
    {
        abort_if($deposit->user_id !== auth()->id(), 403);
    }
}