<?php

namespace App\Http\Controllers;

use App\Services\BudgetService;
use App\Http\Requests\BudgetRequest;
use App\Models\Budget;
use Carbon\Carbon;
use Illuminate\Http\Request;

class BudgetController extends Controller
{
    public function index(Request $request, BudgetService $budgetService)
    {
        // Periode yang ditampilkan (default: bulan ini)
        $month = min(max((int) $request->input('month', now()->month), 1), 12);
        $year = min(max((int) $request->input('year', now()->year), 2020), 2100);

        $budgets = $budgetService->forPeriod($request->user(), $year, $month);

        return view('budgets.index', compact('budgets', 'month', 'year'));
    }

    public function create(Request $request)
    {
        return view('budgets.create', [
            'categories' => $this->kategoriPengeluaran($request),
            'month' => (int) $request->input('month', now()->month),
            'year' => (int) $request->input('year', now()->year),
        ]);
    }

    public function store(BudgetRequest $request)
    {
        $data = $request->validated();

        $request->user()->budgets()->create($data);

        return redirect()
            ->route('budgets.index', ['month' => $data['month'], 'year' => $data['year']])
            ->with('success', 'Anggaran berhasil ditambahkan.');
    }

    public function edit(Request $request, Budget $budget)
    {
        $this->pastikanMilikSendiri($budget);

        return view('budgets.edit', [
            'budget' => $budget,
            'categories' => $this->kategoriPengeluaran($request),
        ]);
    }

    public function update(BudgetRequest $request, Budget $budget)
    {
        $this->pastikanMilikSendiri($budget);

        $data = $request->validated();

        $budget->update($data);

        return redirect()
            ->route('budgets.index', ['month' => $data['month'], 'year' => $data['year']])
            ->with('success', 'Anggaran berhasil diperbarui.');
    }

    public function destroy(Budget $budget)
    {
        $this->pastikanMilikSendiri($budget);

        $periode = ['month' => $budget->month, 'year' => $budget->year];

        $budget->delete();

        return redirect()->route('budgets.index', $periode)
            ->with('success', 'Anggaran berhasil dihapus.');
    }

    // Anggaran hanya untuk kategori pengeluaran
    private function kategoriPengeluaran(Request $request)
    {
        return $request->user()->categories()
            ->where('type', 'expense')
            ->orderBy('name')
            ->get();
    }

    private function pastikanMilikSendiri(Budget $budget): void
    {
        abort_if($budget->user_id !== auth()->id(), 403);
    }
}