<?php

namespace App\Http\Controllers;

use App\Services\BudgetService;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request, BudgetService $budgetService)
    {
        $user = $request->user();

        // Total seluruh waktu
        $totalPemasukan = (int) $user->transactions()->where('type', 'income')->sum('amount');
        $totalPengeluaran = (int) $user->transactions()->where('type', 'expense')->sum('amount');

        // Nanti saat fitur tabungan jadi, rumusnya menjadi:
        // sisa uang = pemasukan - pengeluaran - setoran tabungan
        $sisaUang = $totalPemasukan - $totalPengeluaran;

        // Khusus bulan ini
        $awalBulan = now()->startOfMonth()->toDateString();
        $akhirBulan = now()->endOfMonth()->toDateString();

        $pemasukanBulanIni = (int) $user->transactions()
            ->where('type', 'income')
            ->whereBetween('transaction_date', [$awalBulan, $akhirBulan])
            ->sum('amount');

        $pengeluaranBulanIni = (int) $user->transactions()
            ->where('type', 'expense')
            ->whereBetween('transaction_date', [$awalBulan, $akhirBulan])
            ->sum('amount');

        // 5 transaksi terakhir
        $transaksiTerakhir = $user->transactions()
            ->with('category')
            ->latest('transaction_date')
            ->latest('id')
            ->limit(5)
            ->get();

        // Anggaran bulan ini yang sudah di atas 80%
        $peringatan = $budgetService
            ->forPeriod($user, now()->year, now()->month)
            ->where('status', '!=', 'success');

        return view('dashboard', compact(
            'sisaUang',
            'pemasukanBulanIni',
            'pengeluaranBulanIni',
            'transaksiTerakhir',
            'peringatan'
        ));
    }
}