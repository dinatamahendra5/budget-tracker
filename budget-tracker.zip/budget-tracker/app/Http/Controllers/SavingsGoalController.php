<?php

namespace App\Http\Controllers;

use App\Http\Requests\SavingsGoalRequest;
use App\Models\SavingsGoal;
use App\Services\BalanceService;
use App\Services\SavingsService;
use Illuminate\Http\Request;

class SavingsGoalController extends Controller
{
    public function index(Request $request, SavingsService $savings)
    {
        $goals = $request->user()->savingsGoals()
            ->withSum('deposits', 'amount')
            ->withMin('deposits', 'deposit_date')
            ->latest()
            ->get()
            ->each(fn ($goal) => $savings->summarize($goal));

        return view('savings.index', compact('goals'));
    }

    public function create()
    {
        return view('savings.create');
    }

    public function store(SavingsGoalRequest $request)
    {
        $goal = $request->user()->savingsGoals()->create($request->validated());

        return redirect()->route('savings-goals.show', $goal)
            ->with('success', 'Target tabungan berhasil dibuat. Silakan mulai menyetor.');
    }

    public function show(
        Request $request,
        SavingsGoal $savingsGoal,
        SavingsService $savings,
        BalanceService $balance
    ) {
        $this->pastikanMilikSendiri($savingsGoal);

        $savingsGoal->loadSum('deposits', 'amount')->loadMin('deposits', 'deposit_date');
        $savings->summarize($savingsGoal);

        return view('savings.show', [
            'goal' => $savingsGoal,
            'deposits' => $savingsGoal->deposits()->latest('deposit_date')->latest('id')->get(),
            'saldo' => $balance->saldo($request->user()),
        ]);
    }

    public function edit(SavingsGoal $savingsGoal)
    {
        $this->pastikanMilikSendiri($savingsGoal);

        return view('savings.edit', ['goal' => $savingsGoal]);
    }

    public function update(SavingsGoalRequest $request, SavingsGoal $savingsGoal)
    {
        $this->pastikanMilikSendiri($savingsGoal);

        $savingsGoal->update($request->validated());

        return redirect()->route('savings-goals.show', $savingsGoal)
            ->with('success', 'Target tabungan berhasil diperbarui.');
    }

    public function destroy(SavingsGoal $savingsGoal)
    {
        $this->pastikanMilikSendiri($savingsGoal);

        // Setoran ikut terhapus (cascade), jadi uangnya kembali ke sisa uang
        $savingsGoal->delete();

        return redirect()->route('savings-goals.index')
            ->with('success', 'Target tabungan berhasil dihapus.');
    }

    private function pastikanMilikSendiri(SavingsGoal $goal): void
    {
        abort_if($goal->user_id !== auth()->id(), 403);
    }
}