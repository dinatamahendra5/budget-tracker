<?php

namespace App\Http\Controllers;

use App\Http\Requests\CategoryRequest;
use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index(Request $request)
    {
            $categories = $request->user()->categories()
            ->withCount('transactions')
            ->orderBy('name')
            ->get();

        return view('categories.index', [
            'expense' => $categories->where('type', 'expense'),
            'income' => $categories->where('type', 'income'),
        ]);
    }

    public function create()
    {
        return view('categories.create');
    }

    public function store(CategoryRequest $request)
    {
        $request->user()->categories()->create($request->validated());

        return redirect()->route('categories.index')
            ->with('success', 'Kategori berhasil ditambahkan.');
    }

    public function edit(Category $category)
    {
        $this->pastikanMilikSendiri($category);

        return view('categories.edit', compact('category'));
    }

    public function update(CategoryRequest $request, Category $category)
    {
        $this->pastikanMilikSendiri($category);

        $category->update($request->validated());

        return redirect()->route('categories.index')
            ->with('success', 'Kategori berhasil diperbarui.');
    }

        public function destroy(Category $category)
    {
        $this->pastikanMilikSendiri($category);

        $dipakai = $category->transactions()->count();

        if ($dipakai > 0) {
            return back()->with(
                'error',
                "Kategori \"{$category->name}\" tidak bisa dihapus karena masih dipakai {$dipakai} transaksi."
            );
        }

        $punyaAnggaran = $category->budgets()->count();

        if ($punyaAnggaran > 0) {
            return back()->with(
                'error',
                "Kategori \"{$category->name}\" tidak bisa dihapus karena masih punya {$punyaAnggaran} anggaran."
            );
        }

        $category->delete();

        return redirect()->route('categories.index')
            ->with('success', 'Kategori berhasil dihapus.');
    }

    // User tidak boleh mengubah atau menghapus kategori milik orang lain
    private function pastikanMilikSendiri(Category $category): void
    {
        abort_if($category->user_id !== auth()->id(), 403);
    }
}