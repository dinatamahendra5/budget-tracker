<?php

namespace App\Http\Controllers;

use App\Http\Requests\TransactionRequest;
use App\Models\Transaction;
use App\Services\BudgetService;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    public function index(Request $request)
    {
        $request->validate([
            'type' => ['nullable', 'in:income,expense'],
            'category_id' => ['nullable', 'integer'],
            'from' => ['nullable', 'date'],
            'to' => ['nullable', 'date', 'after_or_equal:from'],
            'q' => ['nullable', 'string', 'max:100'],
        ], [
            'to.after_or_equal' => 'Tanggal akhir tidak boleh sebelum tanggal awal.',
            'from.date' => 'Format tanggal awal tidak valid.',
            'to.date' => 'Format tanggal akhir tidak valid.',
        ]);

        // Query dasar: hanya transaksi milik user yang login + semua filter
        $query = $request->user()->transactions()
            ->when($request->filled('type'), fn ($q) => $q->where('type', $request->type))
            ->when($request->filled('category_id'), fn ($q) => $q->where('category_id', $request->category_id))
            ->when($request->filled('from'), fn ($q) => $q->whereDate('transaction_date', '>=', $request->from))
            ->when($request->filled('to'), fn ($q) => $q->whereDate('transaction_date', '<=', $request->to))
            ->when($request->filled('q'), function ($q) use ($request) {
                $kata = $request->q;

                // Cari di keterangan ATAU nama kategori
                $q->where(function ($sub) use ($kata) {
                    $sub->where('description', 'like', "%{$kata}%")
                        ->orWhereHas('category', fn ($c) => $c->where('name', 'like', "%{$kata}%"));
                });
            });

        // Total dari hasil yang sudah difilter (seluruh halaman, bukan hanya halaman ini)
        $totalPemasukan = (int) (clone $query)->where('type', 'income')->sum('amount');
        $totalPengeluaran = (int) (clone $query)->where('type', 'expense')->sum('amount');

        $transactions = $query
            ->with('category')
            ->latest('transaction_date')
            ->latest('id')
            ->paginate(15)
            ->withQueryString(); // filter tetap terbawa saat pindah halaman

        return view('transactions.index', [
            'transactions' => $transactions,
            'categories' => $this->daftarKategori($request),
            'totalPemasukan' => $totalPemasukan,
            'totalPengeluaran' => $totalPengeluaran,
        ]);
    }

    public function create(Request $request)
    {
        return view('transactions.create', [
            'categories' => $this->daftarKategori($request),
        ]);
    }

    public function store(TransactionRequest $request, BudgetService $budgetService)
    {
        $transaction = $request->user()->transactions()->create($request->validated());

        return redirect()->route('transactions.index')
            ->with('success', 'Transaksi berhasil disimpan.')
            ->with('budget_alert', $budgetService->alertFor($request->user(), $transaction));
    }

    public function edit(Request $request, Transaction $transaction)
    {
        $this->pastikanMilikSendiri($transaction);

        return view('transactions.edit', [
            'transaction' => $transaction,
            'categories' => $this->daftarKategori($request),
        ]);
    }

    public function update(TransactionRequest $request, Transaction $transaction, BudgetService $budgetService)
    {
        $this->pastikanMilikSendiri($transaction);

        $transaction->update($request->validated());

        return redirect()->route('transactions.index')
            ->with('success', 'Transaksi berhasil diperbarui.')
            ->with('budget_alert', $budgetService->alertFor($request->user(), $transaction));
    }

    public function destroy(Transaction $transaction)
    {
        $this->pastikanMilikSendiri($transaction);

        $transaction->delete();

        return redirect()->route('transactions.index')
            ->with('success', 'Transaksi berhasil dihapus.');
    }

    // Kategori milik user yang sedang login, untuk pilihan di form dan filter
    private function daftarKategori(Request $request)
    {
        return $request->user()->categories()->orderBy('name')->get(['id', 'name', 'type']);
    }

    // User tidak boleh mengubah atau menghapus transaksi milik orang lain
    private function pastikanMilikSendiri(Transaction $transaction): void
    {
        abort_if($transaction->user_id !== auth()->id(), 403);
    }
}