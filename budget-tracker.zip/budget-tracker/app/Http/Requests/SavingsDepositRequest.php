<?php

namespace App\Http\Requests;

use App\Services\BalanceService;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Validator;

class SavingsDepositRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'amount' => ['required', 'integer', 'min:1', 'max:9999999999'],
            'deposit_date' => ['required', 'date', 'before_or_equal:today'],
            'note' => ['nullable', 'string', 'max:255'],
        ];
    }

    // Pengecekan tambahan: setoran tidak boleh melebihi sisa uang
    public function after(): array
    {
        return [
            function (Validator $validator) {
                if ($validator->errors()->has('amount')) {
                    return;
                }

                // Saat edit, route('savingsDeposit') berisi setoran yang sedang diedit
                $deposit = $this->route('savingsDeposit');

                $saldo = app(BalanceService::class)->saldo($this->user(), $deposit?->id);

                if ((int) $this->input('amount') > $saldo) {
                    $tersedia = number_format(max($saldo, 0), 0, ',', '.');

                    $validator->errors()->add('amount', "Setoran melebihi sisa uang (tersedia Rp {$tersedia}).");
                }
            },
        ];
    }

    public function messages(): array
    {
        return [
            'amount.required' => 'Nominal setoran wajib diisi.',
            'amount.integer' => 'Nominal harus berupa angka bulat.',
            'amount.min' => 'Nominal setoran harus lebih dari 0.',
            'amount.max' => 'Nominal terlalu besar.',
            'deposit_date.required' => 'Tanggal setoran wajib diisi.',
            'deposit_date.date' => 'Format tanggal tidak valid.',
            'deposit_date.before_or_equal' => 'Tanggal setoran tidak boleh di masa depan.',
            'note.max' => 'Catatan maksimal 255 karakter.',
        ];
    }
}