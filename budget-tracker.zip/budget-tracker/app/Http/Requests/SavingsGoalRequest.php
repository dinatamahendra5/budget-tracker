<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SavingsGoalRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        // Saat edit, route('savingsGoal') berisi target yang sedang diedit
        $goal = $this->route('savingsGoal');

        $deadline = ['nullable', 'date'];

        // Tenggat harus setelah hari ini, kecuali tenggat lama tidak diubah saat edit
        if (! $goal || $this->input('deadline') !== $goal->deadline?->format('Y-m-d')) {
            $deadline[] = 'after:today';
        }

        return [
            'name' => ['required', 'string', 'max:100'],
            'target_amount' => ['required', 'integer', 'min:1', 'max:9999999999'],
            'deadline' => $deadline,
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Nama target wajib diisi.',
            'name.max' => 'Nama target maksimal 100 karakter.',
            'target_amount.required' => 'Nominal target wajib diisi.',
            'target_amount.integer' => 'Nominal harus berupa angka bulat.',
            'target_amount.min' => 'Nominal target harus lebih dari 0.',
            'target_amount.max' => 'Nominal terlalu besar.',
            'deadline.date' => 'Format tenggat tidak valid.',
            'deadline.after' => 'Tenggat harus setelah hari ini.',
        ];
    }
}