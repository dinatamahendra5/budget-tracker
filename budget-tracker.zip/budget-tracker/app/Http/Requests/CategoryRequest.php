<?php

namespace App\Http\Requests;

use App\Models\Category;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CategoryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        // Saat edit, route('category') berisi kategori yang sedang diedit
        $current = $this->route('category');

        return [
            'type' => ['required', Rule::in(array_keys(Category::TYPES))],
            'name' => [
                'required', 'string', 'max:50',
                Rule::unique('categories', 'name')
                    ->where('user_id', $this->user()->id)
                    ->where('type', $this->input('type'))
                    ->ignore($current?->id),
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'type.required' => 'Tipe wajib dipilih.',
            'type.in' => 'Tipe tidak valid.',
            'name.required' => 'Nama kategori wajib diisi.',
            'name.max' => 'Nama kategori maksimal 50 karakter.',
            'name.unique' => 'Kategori dengan nama dan tipe tersebut sudah ada.',
        ];
    }
}