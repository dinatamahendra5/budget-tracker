<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class BudgetRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        // Saat edit, route('budget') berisi anggaran yang sedang diedit
        $current = $this->route('budget');

        return [
            // Anggaran hanya untuk kategori PENGELUARAN milik user sendiri
            'category_id' => [
                'required',
                Rule::exists('categories', 'id')
                    ->where('user_id', $this->user()->id)
                    ->where('type', 'expense'),

                // Satu kategori hanya boleh punya satu anggaran per bulan
                Rule::unique('budgets', 'category_id')
                    ->where('user_id', $this->user()->id)
                    ->where('year', $this->input('year'))
                    ->where('month', $this->input('month'))
                    ->ignore($current?->id),
            ],

            'month' => ['required', 'integer', 'between:1,12'],
            'year' => ['required', 'integer', 'between:2020,2100'],
            'amount' => ['required', 'integer', 'min:1', 'max:9999999999'],
        ];
    }

    public function messages(): array
    {
        return [
            'category_id.required' => 'Kategori wajib dipilih.',
            'category_id.exists' => 'Kategori tidak valid. Anggaran hanya untuk kategori pengeluaran.',
            'category_id.unique' => 'Kategori ini sudah punya anggaran di bulan tersebut.',
            'month.required' => 'Bulan wajib dipilih.',
            'month.between' => 'Bulan tidak valid.',
            'year.required' => 'Tahun wajib diisi.',
            'year.between' => 'Tahun tidak valid.',
            'amount.required' => 'Nominal anggaran wajib diisi.',
            'amount.integer' => 'Nominal harus berupa angka bulat.',
            'amount.min' => 'Nominal harus lebih dari 0.',
            'amount.max' => 'Nominal terlalu besar.',
        ];
    }
}