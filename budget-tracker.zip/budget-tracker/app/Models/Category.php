<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Category extends Model
{
    public const TYPES = [
        'income' => 'Pemasukan',
        'expense' => 'Pengeluaran',
    ];

    public const DEFAULTS = [
        'expense' => ['Makan', 'Transportasi', 'Belanja', 'Tagihan', 'Hiburan', 'Lainnya'],
        'income' => ['Gaji', 'Bonus', 'Lainnya'],
    ];

    protected $fillable = ['name', 'type'];

    // Salin kategori bawaan ke akun user baru
    public static function createDefaultsFor(User $user): void
    {
        foreach (self::DEFAULTS as $type => $names) {
            foreach ($names as $name) {
                $user->categories()->create(['name' => $name, 'type' => $type]);
            }
        }
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    // Satu kategori dipakai banyak transaksi
    public function transactions(): HasMany
    {
        return $this->hasMany(Transaction::class);
    }

        // Satu kategori bisa punya banyak anggaran (satu per bulan)
    public function budgets(): HasMany
    {
        return $this->hasMany(Budget::class);
    }
}