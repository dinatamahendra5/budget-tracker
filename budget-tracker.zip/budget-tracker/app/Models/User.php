<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

#[Fillable(['name', 'email', 'password'])]
#[Hidden(['password', 'remember_token'])]
class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    // Satu user punya banyak kategori
    public function categories(): HasMany
    {
        return $this->hasMany(Category::class);
    }

        // Satu user punya banyak transaksi
    public function transactions(): HasMany
    {
        return $this->hasMany(Transaction::class);
    }

        // Satu user punya banyak anggaran
    public function budgets(): HasMany
    {
        return $this->hasMany(Budget::class);
    }

        // Satu user punya banyak target tabungan
    public function savingsGoals(): HasMany
    {
        return $this->hasMany(SavingsGoal::class);
    }

    // Satu user punya banyak setoran tabungan
    public function savingsDeposits(): HasMany
    {
        return $this->hasMany(SavingsDeposit::class);
    }
}