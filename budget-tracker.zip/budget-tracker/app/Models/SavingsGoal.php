<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class SavingsGoal extends Model
{
    protected $fillable = [
        'name',
        'target_amount',
        'deadline',
    ];

    protected function casts(): array
    {
        return [
            'target_amount' => 'integer',
            'deadline' => 'date',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    // Satu target punya banyak setoran
    public function deposits(): HasMany
    {
        return $this->hasMany(SavingsDeposit::class);
    }
}