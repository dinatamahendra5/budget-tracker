<?php

namespace App\Services;

use App\Models\User;

class BalanceService
{
    // sisa uang = total pemasukan - total pengeluaran - total setoran tabungan
    // $kecualiSetoranId dipakai saat EDIT setoran: setoran itu sendiri tidak dihitung
    public function saldo(User $user, ?int $kecualiSetoranId = null): int
    {
        $pemasukan = (int) $user->transactions()->where('type', 'income')->sum('amount');
        $pengeluaran = (int) $user->transactions()->where('type', 'expense')->sum('amount');

        $setoran = (int) $user->savingsDeposits()
            ->when($kecualiSetoranId, fn ($q) => $q->where('id', '!=', $kecualiSetoranId))
            ->sum('amount');

        return $pemasukan - $pengeluaran - $setoran;
    }
}