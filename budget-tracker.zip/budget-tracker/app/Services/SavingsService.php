<?php

namespace App\Services;

use App\Models\Budget;
use App\Models\SavingsGoal;
use Carbon\Carbon;

class SavingsService
{
    // Menambahkan hasil hitungan ke sebuah target tabungan.
    // Syarat: target sudah dimuat dengan withSum('deposits', 'amount') dan withMin('deposits', 'deposit_date').
    public function summarize(SavingsGoal $goal): SavingsGoal
    {
        $terkumpul = (int) ($goal->deposits_sum_amount ?? 0);
        $target = $goal->target_amount;
        $sisa = max($target - $terkumpul, 0);
        $tercapai = $terkumpul >= $target;

        $goal->terkumpul = $terkumpul;
        $goal->sisa = $sisa;
        $goal->persen = min((int) floor($terkumpul * 100 / $target), 100);
        $goal->tercapai = $tercapai;
        $goal->rata_setoran = null;

        // ---------- Estimasi tercapai ----------
        if ($tercapai) {
            $goal->estimasi = 'Tercapai';
        } elseif ($terkumpul === 0 || ! $goal->deposits_min_deposit_date) {
            $goal->estimasi = 'Belum bisa dihitung (belum ada setoran)';
        } else {
            $awal = Carbon::parse($goal->deposits_min_deposit_date)->startOfMonth();
            $sekarang = now()->startOfMonth();

            // Jumlah bulan sejak setoran pertama sampai bulan ini (minimal 1)
            $bulan = max(1, ($sekarang->year - $awal->year) * 12 + ($sekarang->month - $awal->month) + 1);

            $rata = $terkumpul / $bulan;
            $bulanLagi = (int) ceil($sisa / $rata);
            $tanggal = now()->startOfMonth()->addMonthsNoOverflow($bulanLagi);

            $goal->rata_setoran = (int) round($rata);
            $goal->estimasi = Budget::MONTHS[$tanggal->month] . ' ' . $tanggal->year . " ({$bulanLagi} bulan lagi)";
        }

        // ---------- Kebutuhan setoran per bulan (kalau ada tenggat) ----------
        $goal->terlambat = false;
        $goal->kebutuhan_bulanan = null;

        if ($goal->deadline && ! $tercapai) {
            if ($goal->deadline->lt(today())) {
                $goal->terlambat = true;
            } else {
                // Sisa hari dibagi 30, dibulatkan ke atas, minimal 1 bulan
                $hari = ($goal->deadline->timestamp - today()->timestamp) / 86400;
                $bulanTersisa = max(1, (int) ceil($hari / 30));

                $goal->kebutuhan_bulanan = (int) ceil($sisa / $bulanTersisa);
            }
        }

        return $goal;
    }
}