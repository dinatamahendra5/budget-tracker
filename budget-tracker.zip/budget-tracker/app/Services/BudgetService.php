<?php

namespace App\Services;

use App\Models\Budget;
use App\Models\Transaction;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Collection;

class BudgetService
{
    // Daftar anggaran satu bulan, lengkap dengan terpakai, persen, dan status
    public function forPeriod(User $user, int $year, int $month): Collection
    {
        $awal = Carbon::create($year, $month, 1)->toDateString();
        $akhir = Carbon::create($year, $month, 1)->endOfMonth()->toDateString();

        // Total pengeluaran per kategori (satu query untuk semua kategori)
        $terpakai = $user->transactions()
            ->where('type', 'expense')
            ->whereBetween('transaction_date', [$awal, $akhir])
            ->selectRaw('category_id, SUM(amount) as total')
            ->groupBy('category_id')
            ->pluck('total', 'category_id');

        $budgets = $user->budgets()
            ->with('category')
            ->where('year', $year)
            ->where('month', $month)
            ->get()
            ->sortBy('category.name')
            ->values();

        foreach ($budgets as $budget) {
            $budget->terpakai = (int) ($terpakai[$budget->category_id] ?? 0);
            $budget->persen = (int) floor($budget->terpakai * 100 / $budget->amount);

            // 100% ke atas = danger, 80% ke atas = warning, selain itu success
            if ($budget->terpakai >= $budget->amount) {
                $budget->status = 'danger';
            } elseif ($budget->terpakai * 100 >= $budget->amount * 80) {
                $budget->status = 'warning';
            } else {
                $budget->status = 'success';
            }
        }

        return $budgets;
    }

    // Peringatan setelah sebuah transaksi disimpan (null kalau tidak perlu)
    public function alertFor(User $user, Transaction $transaction): ?array
    {
        if ($transaction->type !== 'expense') {
            return null;
        }

        $date = $transaction->transaction_date;

        $budget = $this->forPeriod($user, $date->year, $date->month)
            ->firstWhere('category_id', $transaction->category_id);

        if (! $budget || $budget->status === 'success') {
            return null;
        }

        $periode = Budget::MONTHS[$date->month] . ' ' . $date->year;

        $message = $budget->status === 'danger'
            ? "Anggaran {$budget->category->name} {$periode} sudah terpakai {$budget->persen}% dan mencapai atau melewati batas."
            : "Anggaran {$budget->category->name} {$periode} sudah terpakai {$budget->persen}%, hampir mencapai batas.";

        return ['level' => $budget->status, 'message' => $message];
    }
}