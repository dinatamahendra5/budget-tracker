<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\BudgetController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\SavingsDepositController;
use App\Http\Controllers\SavingsGoalController;
use App\Http\Controllers\TransactionController;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/login');

// Hanya untuk yang BELUM login
Route::middleware('guest')->group(function () {
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.store');
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.store');
});

// Hanya untuk yang SUDAH login
Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::resource('categories', CategoryController::class)->except('show');
    Route::resource('transactions', TransactionController::class)->except('show');
    Route::resource('budgets', BudgetController::class)->except('show');

    // Target tabungan (ada halaman detail/show yang memuat daftar setoran)
    Route::resource('savings-goals', SavingsGoalController::class)
        ->parameters(['savings-goals' => 'savingsGoal']);

    // Setoran: tambah lewat halaman target, edit dan hapus lewat resource
    Route::post('savings-goals/{savingsGoal}/deposits', [SavingsDepositController::class, 'store'])
        ->name('savings-deposits.store');
    Route::resource('savings-deposits', SavingsDepositController::class)
        ->only(['edit', 'update', 'destroy'])
        ->parameters(['savings-deposits' => 'savingsDeposit']);
});