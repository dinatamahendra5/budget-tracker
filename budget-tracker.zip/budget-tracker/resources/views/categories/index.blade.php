@extends('layouts.app')

@section('title', 'Kategori')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Kategori</h4>
    <a href="{{ route('categories.create') }}" class="btn btn-primary">+ Tambah Kategori</a>
</div>

<div class="row g-3">
    @foreach (['expense' => $expense, 'income' => $income] as $type => $items)
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header fw-semibold">{{ \App\Models\Category::TYPES[$type] }}</div>
                <ul class="list-group list-group-flush">
                    @forelse ($items as $c)
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            {{ $c->name }}
                            <span class="badge text-bg-secondary">{{ $c->transactions_count }}</span>
                            <span class="d-flex gap-2">
                                <a href="{{ route('categories.edit', $c) }}" class="btn btn-sm btn-outline-primary">Edit</a>
                                <form method="POST" action="{{ route('categories.destroy', $c) }}"
                                    onsubmit="return confirm('Hapus kategori ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                            </span>
                        </li>
                    @empty
                        <li class="list-group-item text-muted">Belum ada kategori.</li>
                    @endforelse
                </ul>
            </div>
        </div>
    @endforeach
</div>
@endsection