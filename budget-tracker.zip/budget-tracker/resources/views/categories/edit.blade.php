@extends('layouts.app')

@section('title', 'Edit Kategori')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body">
                <h4 class="mb-3">Edit Kategori</h4>
                <form method="POST" action="{{ route('categories.update', $category) }}">
                    @method('PUT')
                    @include('categories._form')
                </form>
            </div>
        </div>
    </div>
</div>
@endsection