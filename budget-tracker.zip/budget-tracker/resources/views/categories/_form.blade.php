@csrf

<div class="mb-3">
    <label class="form-label">Tipe</label>
    <select name="type" class="form-select @error('type') is-invalid @enderror">
        @foreach (\App\Models\Category::TYPES as $value => $label)
            <option value="{{ $value }}"
                @selected(old('type', $category->type ?? 'expense') === $value)>
                {{ $label }}
            </option>
        @endforeach
    </select>
    @error('type') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="mb-3">
    <label class="form-label">Nama kategori</label>
    <input type="text" name="name" maxlength="50"
           value="{{ old('name', $category->name ?? '') }}"
           class="form-control @error('name') is-invalid @enderror">
    @error('name') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<button class="btn btn-primary">Simpan</button>
<a href="{{ route('categories.index') }}" class="btn btn-secondary">Batal</a>