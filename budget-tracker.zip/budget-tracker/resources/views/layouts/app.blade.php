<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Keuangan Pribadi')</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="{{ route('dashboard') }}">Keuangan Pribadi</a>

        @auth
            <ul class="navbar-nav flex-row gap-3 me-auto ms-4">
                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}"
                    href="{{ route('dashboard') }}">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('categories.*') ? 'active' : '' }}"
                    href="{{ route('categories.index') }}">Kategori</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('transactions.*') ? 'active' : '' }}"
                    href="{{ route('transactions.index') }}">Transaksi</a>
                </li>
                    <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('budgets.*') ? 'active' : '' }}"
                    href="{{ route('budgets.index') }}">Anggaran</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('savings-goals.*', 'savings-deposits.*') ? 'active' : '' }}"
                    href="{{ route('savings-goals.index') }}">Tabungan</a>
                </li>
            </ul>

            <div class="d-flex align-items-center gap-3">
                <span class="text-white">{{ auth()->user()->name }}</span>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button class="btn btn-sm btn-light">Logout</button>
                </form>
            </div>
        @endauth
    </div>
</nav>

<main class="container py-4">
    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    @if (session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

        @if (session('budget_alert'))
        @php $alert = session('budget_alert'); @endphp
        <div class="alert alert-{{ $alert['level'] }}">{{ $alert['message'] }}</div>
        @endif

    @yield('content')
</main>

</body>
</html>