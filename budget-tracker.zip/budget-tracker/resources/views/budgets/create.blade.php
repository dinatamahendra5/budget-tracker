@extends('layouts.app')

@section('title', 'Tambah Anggaran')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body">
                <h4 class="mb-3">Tambah Anggaran</h4>
                <form method="POST" action="{{ route('budgets.store') }}">
                    @include('budgets._form')
                </form>
            </div>
        </div>
    </div>
</div>
@endsection