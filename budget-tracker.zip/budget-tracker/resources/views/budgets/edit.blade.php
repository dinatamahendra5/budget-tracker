@extends('layouts.app')

@section('title', 'Edit Anggaran')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body">
                <h4 class="mb-3">Edit Anggaran</h4>
                <form method="POST" action="{{ route('budgets.update', $budget) }}">
                    @method('PUT')
                    @include('budgets._form', ['month' => $budget->month, 'year' => $budget->year])
                </form>
            </div>
        </div>
    </div>
</div>
@endsection