@extends('layouts.app')

@section('title', 'Anggaran')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Anggaran</h4>
    <a href="{{ route('budgets.create', ['month' => $month, 'year' => $year]) }}"
       class="btn btn-primary">+ Tambah Anggaran</a>
</div>

{{-- Pilih periode --}}
<form method="GET" action="{{ route('budgets.index') }}" class="row g-2 mb-3">
    <div class="col-auto">
        <select name="month" class="form-select">
            @foreach (\App\Models\Budget::MONTHS as $num => $nama)
                <option value="{{ $num }}" @selected($month === $num)>{{ $nama }}</option>
            @endforeach
        </select>
    </div>
    <div class="col-auto">
        <input type="number" name="year" value="{{ $year }}" min="2020" max="2100" class="form-control">
    </div>
    <div class="col-auto">
        <button class="btn btn-outline-primary">Tampilkan</button>
    </div>
</form>

{{-- Peringatan 80% dan 100% --}}
@foreach ($budgets as $b)
    @if ($b->status === 'danger')
        <div class="alert alert-danger py-2">
            <strong>{{ $b->category->name }}</strong> sudah mencapai atau melewati batas anggaran ({{ $b->persen }}%).
        </div>
    @elseif ($b->status === 'warning')
        <div class="alert alert-warning py-2">
            <strong>{{ $b->category->name }}</strong> sudah terpakai {{ $b->persen }}%, hampir mencapai batas anggaran.
        </div>
    @endif
@endforeach

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Kategori</th>
                    <th style="min-width: 240px;">Terpakai</th>
                    <th class="text-end">Anggaran</th>
                    <th class="text-end">Sisa</th>
                    <th class="text-end">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($budgets as $b)
                    @php $sisa = $b->amount - $b->terpakai; @endphp
                    <tr>
                        <td>{{ $b->category->name }}</td>
                        <td>
                            <div class="progress" style="height: 22px;">
                                <div class="progress-bar bg-{{ $b->status }} {{ $b->status === 'warning' ? 'text-dark' : '' }}"
                                     style="width: {{ min($b->persen, 100) }}%;">
                                    {{ $b->persen }}%
                                </div>
                            </div>
                            <div class="small text-muted mt-1">
                                Rp {{ number_format($b->terpakai, 0, ',', '.') }}
                            </div>
                        </td>
                        <td class="text-end">Rp {{ number_format($b->amount, 0, ',', '.') }}</td>
                        <td class="text-end {{ $sisa < 0 ? 'text-danger fw-semibold' : '' }}">
                            @if ($sisa < 0)
                                Melebihi Rp {{ number_format(abs($sisa), 0, ',', '.') }}
                            @else
                                Rp {{ number_format($sisa, 0, ',', '.') }}
                            @endif
                        </td>
                        <td class="text-end">
                            <div class="d-inline-flex gap-2">
                                <a href="{{ route('budgets.edit', $b) }}" class="btn btn-sm btn-outline-primary">Edit</a>
                                <form method="POST" action="{{ route('budgets.destroy', $b) }}"
                                      onsubmit="return confirm('Hapus anggaran ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">
                            Belum ada anggaran untuk {{ \App\Models\Budget::MONTHS[$month] }} {{ $year }}.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection