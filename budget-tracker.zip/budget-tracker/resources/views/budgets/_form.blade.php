@csrf

<div class="mb-3">
    <label class="form-label">Kategori pengeluaran</label>
    <select name="category_id" class="form-select @error('category_id') is-invalid @enderror">
        <option value="">-- Pilih kategori --</option>
        @foreach ($categories as $c)
            <option value="{{ $c->id }}"
                @selected((string) old('category_id', $budget->category_id ?? '') === (string) $c->id)>
                {{ $c->name }}
            </option>
        @endforeach
    </select>
    @error('category_id') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="row">
    <div class="col-md-7 mb-3">
        <label class="form-label">Bulan</label>
        <select name="month" class="form-select @error('month') is-invalid @enderror">
            @foreach (\App\Models\Budget::MONTHS as $num => $nama)
                <option value="{{ $num }}"
                    @selected((int) old('month', $budget->month ?? $month) === $num)>
                    {{ $nama }}
                </option>
            @endforeach
        </select>
        @error('month') <div class="invalid-feedback">{{ $message }}</div> @enderror
    </div>

    <div class="col-md-5 mb-3">
        <label class="form-label">Tahun</label>
        <input type="number" name="year" min="2020" max="2100"
               value="{{ old('year', $budget->year ?? $year) }}"
               class="form-control @error('year') is-invalid @enderror">
        @error('year') <div class="invalid-feedback">{{ $message }}</div> @enderror
    </div>
</div>

<div class="mb-3">
    <label class="form-label">Nominal anggaran (Rp)</label>
    <input type="number" name="amount" min="1" step="1"
           value="{{ old('amount', $budget->amount ?? '') }}"
           class="form-control @error('amount') is-invalid @enderror">
    @error('amount') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<button class="btn btn-primary">Simpan</button>
<a href="{{ route('budgets.index') }}" class="btn btn-secondary">Batal</a>