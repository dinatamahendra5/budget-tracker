@extends('layouts.app')

@section('title', 'Transaksi')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Transaksi</h4>
    <a href="{{ route('transactions.create') }}" class="btn btn-primary">+ Tambah Transaksi</a>
</div>

{{-- Filter dan pencarian --}}
<form method="GET" action="{{ route('transactions.index') }}" class="card shadow-sm mb-3">
    <div class="card-body">
        <div class="row g-2">
            <div class="col-md-4">
                <label class="form-label small mb-1">Cari</label>
                <input type="text" name="q" value="{{ request('q') }}"
                class="form-control" placeholder="Keterangan atau kategori">
            </div>

            <div class="col-md-2">
                <label class="form-label small mb-1">Tipe</label>
                <select name="type" class="form-select">
                    <option value="">Semua</option>
                    <option value="income" @selected(request('type') === 'income')>Pemasukan</option>
                    <option value="expense" @selected(request('type') === 'expense')>Pengeluaran</option>
                </select>
            </div>

            <div class="col-md-3">
                <label class="form-label small mb-1">Kategori</label>
                <select name="category_id" class="form-select">
                    <option value="">Semua</option>
                    @foreach ($categories as $c)
                        <option value="{{ $c->id }}" @selected((string) request('category_id') === (string) $c->id)>
                            {{ $c->name }} ({{ $c->type === 'income' ? 'Masuk' : 'Keluar' }})
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="col-md-3"></div>

            <div class="col-md-3">
                <label class="form-label small mb-1">Dari tanggal</label>
                <input type="date" name="from" value="{{ request('from') }}"
                       class="form-control @error('from') is-invalid @enderror">
                @error('from') <div class="invalid-feedback">{{ $message }}</div> @enderror
            </div>

            <div class="col-md-3">
                <label class="form-label small mb-1">Sampai tanggal</label>
                <input type="date" name="to" value="{{ request('to') }}"
                       class="form-control @error('to') is-invalid @enderror">
                @error('to') <div class="invalid-feedback">{{ $message }}</div> @enderror
            </div>

            <div class="col-md-6 d-flex align-items-end gap-2">
                <button class="btn btn-primary">Terapkan</button>
                <a href="{{ route('transactions.index') }}" class="btn btn-outline-secondary">Reset</a>
            </div>
        </div>
    </div>
</form>

{{-- Ringkasan hasil filter --}}
<div class="row g-3 mb-3">
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body py-2">
                <div class="text-muted small">Jumlah transaksi</div>
                <div class="fw-bold">{{ $transactions->total() }}</div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body py-2">
                <div class="text-muted small">Total pemasukan</div>
                <div class="fw-bold text-success">Rp {{ number_format($totalPemasukan, 0, ',', '.') }}</div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body py-2">
                <div class="text-muted small">Total pengeluaran</div>
                <div class="fw-bold text-danger">Rp {{ number_format($totalPengeluaran, 0, ',', '.') }}</div>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Tanggal</th>
                    <th>Kategori</th>
                    <th>Keterangan</th>
                    <th class="text-end">Jumlah</th>
                    <th class="text-end">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($transactions as $t)
                    <tr>
                        <td>{{ $t->transaction_date->format('d M Y') }}</td>
                        <td>{{ $t->category->name }}</td>
                        <td class="text-muted">{{ $t->description }}</td>
                        <td class="text-end fw-semibold {{ $t->isIncome() ? 'text-success' : 'text-danger' }}">
                            {{ $t->isIncome() ? '+' : '-' }} Rp {{ number_format($t->amount, 0, ',', '.') }}
                        </td>
                        <td class="text-end">
                            <div class="d-inline-flex gap-2">
                                <a href="{{ route('transactions.edit', $t) }}" class="btn btn-sm btn-outline-primary">Edit</a>
                                <form method="POST" action="{{ route('transactions.destroy', $t) }}"
                                      onsubmit="return confirm('Hapus transaksi ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">
                            Tidak ada transaksi yang cocok.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">
    {{ $transactions->links('pagination::bootstrap-5') }}
</div>
@endsection