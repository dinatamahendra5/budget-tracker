@csrf

@php
    $selectedType = old('type', $transaction->type ?? 'expense');
    $selectedCategory = old('category_id', $transaction->category_id ?? '');
@endphp

<div class="mb-3">
    <label class="form-label d-block">Tipe</label>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="type" id="type_expense" value="expense"
               @checked($selectedType === 'expense')>
        <label class="form-check-label" for="type_expense">Pengeluaran</label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="type" id="type_income" value="income"
               @checked($selectedType === 'income')>
        <label class="form-check-label" for="type_income">Pemasukan</label>
    </div>
    @error('type') <div class="text-danger small">{{ $message }}</div> @enderror
</div>

<div class="mb-3">
    <label class="form-label">Kategori</label>
    <select name="category_id" id="category_id"
            class="form-select @error('category_id') is-invalid @enderror"></select>
    @error('category_id') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="mb-3">
    <label class="form-label">Nominal (Rp)</label>
    <input type="number" name="amount" min="1" step="1"
           value="{{ old('amount', $transaction->amount ?? '') }}"
           class="form-control @error('amount') is-invalid @enderror">
    @error('amount') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="mb-3">
    <label class="form-label">Tanggal</label>
    <input type="date" name="transaction_date" max="{{ now()->format('Y-m-d') }}"
           value="{{ old('transaction_date', isset($transaction) ? $transaction->transaction_date->format('Y-m-d') : now()->format('Y-m-d')) }}"
           class="form-control @error('transaction_date') is-invalid @enderror">
    @error('transaction_date') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="mb-3">
    <label class="form-label">Keterangan (opsional)</label>
    <input type="text" name="description" maxlength="255"
        value="{{ old('description', $transaction->description ?? '') }}"
        class="form-control @error('description') is-invalid @enderror">
    @error('description') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<button class="btn btn-primary">Simpan</button>
<a href="{{ route('transactions.index') }}" class="btn btn-secondary">Batal</a>

<script>
    const categories = @json($categories);
    const selectedCategory = "{{ $selectedCategory }}";
    const select = document.getElementById('category_id');

    function renderOptions(keepSelected) {
        const type = document.querySelector('input[name="type"]:checked').value;

        select.innerHTML = '<option value="">-- Pilih kategori --</option>';

        categories.filter(c => c.type === type).forEach(c => {
            const option = document.createElement('option');
            option.value = c.id;
            option.textContent = c.name;
            if (keepSelected && String(c.id) === selectedCategory) {
                option.selected = true;
            }
            select.appendChild(option);
        });
    }

    document.querySelectorAll('input[name="type"]').forEach(radio => {
        radio.addEventListener('change', () => renderOptions(false));
    });

    renderOptions(true);
</script>