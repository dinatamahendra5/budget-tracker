@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<h4 class="mb-3">Dashboard</h4>

@foreach ($peringatan as $b)
    <div class="alert alert-{{ $b->status }} py-2">
        <strong>{{ $b->category->name }}</strong>
        sudah terpakai {{ $b->persen }}% dari anggaran bulan ini
        (Rp {{ number_format($b->terpakai, 0, ',', '.') }} dari Rp {{ number_format($b->amount, 0, ',', '.') }}).
        <a href="{{ route('budgets.index') }}" class="alert-link">Lihat anggaran</a>
    </div>
@endforeach

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <div class="text-muted small">Sisa uang</div>
                <div class="fs-4 fw-bold {{ $sisaUang < 0 ? 'text-danger' : '' }}">
                    Rp {{ number_format($sisaUang, 0, ',', '.') }}
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <div class="text-muted small">Pemasukan bulan ini ({{ now()->format('m/Y') }})</div>
                <div class="fs-4 fw-bold text-success">
                    Rp {{ number_format($pemasukanBulanIni, 0, ',', '.') }}
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <div class="text-muted small">Pengeluaran bulan ini ({{ now()->format('m/Y') }})</div>
                <div class="fs-4 fw-bold text-danger">
                    Rp {{ number_format($pengeluaranBulanIni, 0, ',', '.') }}
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span class="fw-semibold">5 transaksi terakhir</span>
        <a href="{{ route('transactions.create') }}" class="btn btn-sm btn-primary">+ Tambah Transaksi</a>
    </div>
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <tbody>
                @forelse ($transaksiTerakhir as $t)
                    <tr>
                        <td>{{ $t->transaction_date->format('d M Y') }}</td>
                        <td>{{ $t->category->name }}</td>
                        <td class="text-muted">{{ $t->description }}</td>
                        <td class="text-end fw-semibold {{ $t->isIncome() ? 'text-success' : 'text-danger' }}">
                            {{ $t->isIncome() ? '+' : '-' }} Rp {{ number_format($t->amount, 0, ',', '.') }}
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td class="text-center text-muted py-4">Belum ada transaksi.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection