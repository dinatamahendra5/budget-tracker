@csrf

<div class="mb-3">
    <label class="form-label">Nama target</label>
    <input type="text" name="name" maxlength="100"
           value="{{ old('name', $goal->name ?? '') }}"
           placeholder="Contoh: Beli laptop"
           class="form-control @error('name') is-invalid @enderror">
    @error('name') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="mb-3">
    <label class="form-label">Nominal target (Rp)</label>
    <input type="number" name="target_amount" min="1" step="1"
           value="{{ old('target_amount', $goal->target_amount ?? '') }}"
           class="form-control @error('target_amount') is-invalid @enderror">
    @error('target_amount') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<div class="mb-3">
    <label class="form-label">Tenggat (opsional)</label>
    <input type="date" name="deadline"
           value="{{ old('deadline', isset($goal) ? $goal->deadline?->format('Y-m-d') : '') }}"
           class="form-control @error('deadline') is-invalid @enderror">
    @error('deadline') <div class="invalid-feedback">{{ $message }}</div> @enderror
</div>

<button class="btn btn-primary">Simpan</button>
<a href="{{ route('savings-goals.index') }}" class="btn btn-secondary">Batal</a>