@extends('layouts.app')

@section('title', 'Tabungan')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Target Tabungan</h4>
    <a href="{{ route('savings-goals.create') }}" class="btn btn-primary">+ Tambah Target</a>
</div>

<div class="row g-3">
    @forelse ($goals as $g)
        <div class="col-md-6">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <h5 class="mb-1">{{ $g->name }}</h5>
                        @if ($g->tercapai)
                            <span class="badge text-bg-success">Tercapai</span>
                        @elseif ($g->terlambat)
                            <span class="badge text-bg-danger">Lewat tenggat</span>
                        @endif
                    </div>

                    <div class="text-muted small mb-2">
                        @if ($g->deadline)
                            Tenggat: {{ $g->deadline->format('d M Y') }}
                        @else
                            Tanpa tenggat
                        @endif
                    </div>

                    <div class="progress mb-2" style="height: 22px;">
                        <div class="progress-bar {{ $g->tercapai ? 'bg-success' : 'bg-primary' }}"
                             style="width: {{ $g->persen }}%;">{{ $g->persen }}%</div>
                    </div>

                    <div class="d-flex justify-content-between small">
                        <span>Rp {{ number_format($g->terkumpul, 0, ',', '.') }}</span>
                        <span class="text-muted">dari Rp {{ number_format($g->target_amount, 0, ',', '.') }}</span>
                    </div>

                    <div class="small text-muted mt-2">Estimasi tercapai: {{ $g->estimasi }}</div>
                </div>
                <div class="card-footer bg-transparent">
                    <a href="{{ route('savings-goals.show', $g) }}" class="btn btn-sm btn-outline-primary">Detail &amp; Setoran</a>
                </div>
            </div>
        </div>
    @empty
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-body text-center text-muted py-4">
                    Belum ada target tabungan. Klik "+ Tambah Target" untuk membuat yang pertama.
                </div>
            </div>
        </div>
    @endforelse
</div>
@endsection