@extends('layouts.app')

@section('title', $goal->name)

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">{{ $goal->name }}</h4>
    <div class="d-flex gap-2">
        <a href="{{ route('savings-goals.index') }}" class="btn btn-outline-secondary btn-sm">&laquo; Kembali</a>
        <a href="{{ route('savings-goals.edit', $goal) }}" class="btn btn-outline-primary btn-sm">Edit</a>
        <form method="POST" action="{{ route('savings-goals.destroy', $goal) }}"
              onsubmit="return confirm('Hapus target ini? Semua setorannya ikut terhapus dan uangnya kembali ke sisa uang.')">
            @csrf
            @method('DELETE')
            <button class="btn btn-outline-danger btn-sm">Hapus</button>
        </form>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-8">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <div class="progress mb-2" style="height: 28px;">
                    <div class="progress-bar {{ $goal->tercapai ? 'bg-success' : 'bg-primary' }}"
                         style="width: {{ $goal->persen }}%;">{{ $goal->persen }}%</div>
                </div>

                <div class="row text-center mt-3">
                    <div class="col">
                        <div class="text-muted small">Terkumpul</div>
                        <div class="fw-bold text-success">Rp {{ number_format($goal->terkumpul, 0, ',', '.') }}</div>
                    </div>
                    <div class="col">
                        <div class="text-muted small">Target</div>
                        <div class="fw-bold">Rp {{ number_format($goal->target_amount, 0, ',', '.') }}</div>
                    </div>
                    <div class="col">
                        <div class="text-muted small">Kurang</div>
                        <div class="fw-bold">Rp {{ number_format($goal->sisa, 0, ',', '.') }}</div>
                    </div>
                </div>

                <hr>

                <div class="small">
                    <div class="mb-1">
                        <span class="text-muted">Estimasi tercapai:</span>
                        <strong>{{ $goal->estimasi }}</strong>
                    </div>

                    @if ($goal->rata_setoran)
                        <div class="mb-1">
                            <span class="text-muted">Rata-rata setoran per bulan:</span>
                            <strong>Rp {{ number_format($goal->rata_setoran, 0, ',', '.') }}</strong>
                        </div>
                    @endif

                    @if ($goal->deadline)
                        <div class="mb-1">
                            <span class="text-muted">Tenggat:</span>
                            <strong>{{ $goal->deadline->format('d M Y') }}</strong>
                        </div>
                    @endif

                    @if ($goal->terlambat)
                        <div class="text-danger fw-semibold">Tenggat sudah lewat dan target belum tercapai.</div>
                    @elseif ($goal->kebutuhan_bulanan)
                        <div>
                            <span class="text-muted">Perlu menyetor:</span>
                            <strong>Rp {{ number_format($goal->kebutuhan_bulanan, 0, ',', '.') }} / bulan</strong>
                            <span class="text-muted">agar tercapai sebelum tenggat</span>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <h6 class="mb-1">Tambah setoran</h6>
                <div class="text-muted small mb-3">
                    Sisa uang tersedia: Rp {{ number_format(max($saldo, 0), 0, ',', '.') }}
                </div>

                <form method="POST" action="{{ route('savings-deposits.store', $goal) }}">
                    @csrf

                    <div class="mb-2">
                        <label class="form-label small mb-1">Nominal (Rp)</label>
                        <input type="number" name="amount" min="1" step="1" value="{{ old('amount') }}"
                               class="form-control @error('amount') is-invalid @enderror">
                        @error('amount') <div class="invalid-feedback">{{ $message }}</div> @enderror
                    </div>

                    <div class="mb-2">
                        <label class="form-label small mb-1">Tanggal</label>
                        <input type="date" name="deposit_date" max="{{ now()->format('Y-m-d') }}"
                               value="{{ old('deposit_date', now()->format('Y-m-d')) }}"
                               class="form-control @error('deposit_date') is-invalid @enderror">
                        @error('deposit_date') <div class="invalid-feedback">{{ $message }}</div> @enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label small mb-1">Catatan (opsional)</label>
                        <input type="text" name="note" maxlength="255" value="{{ old('note') }}"
                               class="form-control @error('note') is-invalid @enderror">
                        @error('note') <div class="invalid-feedback">{{ $message }}</div> @enderror
                    </div>

                    <button class="btn btn-primary w-100">Setor</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header fw-semibold">Riwayat setoran</div>
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <tbody>
                @forelse ($deposits as $d)
                    <tr>
                        <td>{{ $d->deposit_date->format('d M Y') }}</td>
                        <td class="text-muted">{{ $d->note }}</td>
                        <td class="text-end fw-semibold text-success">
                            + Rp {{ number_format($d->amount, 0, ',', '.') }}
                        </td>
                        <td class="text-end">
                            <div class="d-inline-flex gap-2">
                                <a href="{{ route('savings-deposits.edit', $d) }}" class="btn btn-sm btn-outline-primary">Edit</a>
                                <form method="POST" action="{{ route('savings-deposits.destroy', $d) }}"
                                      onsubmit="return confirm('Hapus setoran ini? Uangnya kembali ke sisa uang.')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td class="text-center text-muted py-4">Belum ada setoran.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection