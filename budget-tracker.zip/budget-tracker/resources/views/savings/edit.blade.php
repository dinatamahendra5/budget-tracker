@extends('layouts.app')

@section('title', 'Edit Target Tabungan')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body">
                <h4 class="mb-3">Edit Target Tabungan</h4>
                <form method="POST" action="{{ route('savings-goals.update', $goal) }}">
                    @method('PUT')
                    @include('savings._form')
                </form>
            </div>
        </div>
    </div>
</div>
@endsection