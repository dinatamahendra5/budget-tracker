@extends('layouts.app')

@section('title', 'Edit Setoran')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body">
                <h4 class="mb-1">Edit Setoran</h4>
                <div class="text-muted small mb-3">Target: {{ $goal->name }}</div>

                <form method="POST" action="{{ route('savings-deposits.update', $deposit) }}">
                    @csrf
                    @method('PUT')

                    <div class="mb-3">
                        <label class="form-label">Nominal (Rp)</label>
                        <input type="number" name="amount" min="1" step="1"
                               value="{{ old('amount', $deposit->amount) }}"
                               class="form-control @error('amount') is-invalid @enderror">
                        @error('amount') <div class="invalid-feedback">{{ $message }}</div> @enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Tanggal</label>
                        <input type="date" name="deposit_date" max="{{ now()->format('Y-m-d') }}"
                               value="{{ old('deposit_date', $deposit->deposit_date->format('Y-m-d')) }}"
                               class="form-control @error('deposit_date') is-invalid @enderror">
                        @error('deposit_date') <div class="invalid-feedback">{{ $message }}</div> @enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Catatan (opsional)</label>
                        <input type="text" name="note" maxlength="255"
                               value="{{ old('note', $deposit->note) }}"
                               class="form-control @error('note') is-invalid @enderror">
                        @error('note') <div class="invalid-feedback">{{ $message }}</div> @enderror
                    </div>

                    <button class="btn btn-primary">Simpan</button>
                    <a href="{{ route('savings-goals.show', $goal) }}" class="btn btn-secondary">Batal</a>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection