<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('budgets', function (Blueprint $table) {
        $table->id();
        $table->foreignId('user_id')->constrained()->cascadeOnDelete();
        // restrictOnDelete: kategori yang masih punya anggaran tidak bisa dihapus
        $table->foreignId('category_id')->constrained()->restrictOnDelete();
        $table->unsignedSmallInteger('year');
        $table->unsignedTinyInteger('month');
        $table->unsignedBigInteger('amount');
        $table->timestamps();

        // Satu kategori hanya boleh punya satu anggaran per bulan
        $table->unique(['user_id', 'category_id', 'year', 'month']);
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('budgets');
    }
};
