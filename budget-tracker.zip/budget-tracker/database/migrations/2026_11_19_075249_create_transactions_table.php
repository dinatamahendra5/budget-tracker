<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('transactions', function (Blueprint $table) {
        $table->id();
        $table->foreignId('user_id')->constrained()->cascadeOnDelete();
        // restrictOnDelete: kategori yang masih dipakai transaksi tidak bisa dihapus
        $table->foreignId('category_id')->constrained()->restrictOnDelete();
        $table->enum('type', ['income', 'expense']);
        $table->unsignedBigInteger('amount');
        $table->date('transaction_date');
        $table->string('description')->nullable();
        $table->timestamps();

        $table->index(['user_id', 'transaction_date']);
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('transactions');
    }
};
