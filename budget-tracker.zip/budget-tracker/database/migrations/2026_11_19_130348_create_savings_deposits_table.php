<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('savings_deposits', function (Blueprint $table) {
        $table->id();
        $table->foreignId('user_id')->constrained()->cascadeOnDelete();
        // Target dihapus -> setorannya ikut terhapus (uangnya kembali ke sisa uang)
        $table->foreignId('savings_goal_id')->constrained()->cascadeOnDelete();
        $table->unsignedBigInteger('amount');
        $table->date('deposit_date');
        $table->string('note')->nullable();
        $table->timestamps();

        $table->index(['user_id', 'deposit_date']);
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('savings_deposits');
    }
};
